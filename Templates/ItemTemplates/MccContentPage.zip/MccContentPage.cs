﻿using MinecraftCommandController.Base;

namespace $rootnamespace$
{
	public partial class $safeitemname$ : MccContentPageBase
	{
		private AppMainForm appMainForm; //メインフォームの参照

		//コンストラクタ
		public $safeitemname$(AppMainForm form)
		{
			this.appMainForm = form;
			InitializeComponent();
			init();
		}

		//初期処理
		private void init()
		{
		}

		/* ***** 以下、デザイナからの半自動生成 ***** */
		//未使用コンストラクタ
		public $safeitemname$()
		{
			InitializeComponent();
		}
	}
}
